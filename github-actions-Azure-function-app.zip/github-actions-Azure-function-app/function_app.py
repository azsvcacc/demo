import azure.functions as func
import logging

# Azure Function Application
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

@app.route(route="fntesting3202")
def fntesting3202(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing HTTP trigger function...")

    # Default values for 'a' and 'b'
    a = 3
    b = 3

    # Try to fetch values of 'a' and 'b' from query parameters
    try:
        a = int(req.params.get('a', a))
        b = int(req.params.get('b', b))
    except ValueError:
        logging.error("Invalid values provided for 'a' or 'b'. Using default values (a=3, b=2).")

    # Compute the sum
    c = a + b
    logging.info(f"Computed sum: a={a}, b={b}, c={c}")

    # Get 'name' from query string or request body
    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
            name = req_body.get('name')
        except (ValueError, TypeError):
            logging.warning("Name not provided in query or body.")

    # Construct response message
    if name:
        response_message = f"Hello, {name}. This HTTP triggered function executed successfully."
    else:
        response_message = (
            "This HTTP triggered function executed successfully. "
            f"Pass a name in the query string or in the request body for a personalized response. "
            f"The sum of a + b is {c}."
        )

    logging.info("Returning response...")
    return func.HttpResponse(response_message, status_code=200)
